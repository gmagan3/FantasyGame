/*********************************************************************
** Program name: Final Project
** Author: Guleid Magan
** Date: December 10th, 2019
** Description: This is the Dungeon class which inherits from the Space class. It inherits the runSpace method from Space and sets the name of the class.
*********************************************************************/
#include <iostream>
#include "Dungeon.hpp"
using std::cout;
using std::endl;
using std::cin;
